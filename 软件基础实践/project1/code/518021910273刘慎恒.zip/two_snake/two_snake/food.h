#ifndef FOOD_H
#define FOOD
#include"snakenode.h"
#include<QWidget>
#include"foodnode.h"

class food{
public:
    food(QWidget *parent);
    foodnode*ff;
};

#endif // FOOD_H
